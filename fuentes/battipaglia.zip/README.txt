Note of the author
Battipaglia Font by Ahmad Rofingi

NOTE: This demo font is only for PERSONAL USE! But every donation is greatly appreciated.

Paypal account for donations: paypal.me/ahmadrofingi

for commercial license contact
email: ahmadrofingi97@gmail.com

Shop:
https://fontbundles.net/ahmadrofingi97/feed
https://www.creativefabrica.com/designer/ahmadrofingi97/